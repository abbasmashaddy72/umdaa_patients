<div>
    <div class="container p-3 mt-4 mb-4">
        <div class="row">
            <div class="mb-2 col-lg-4 col-12 col-md-4">
                <select class="form-select w-100" wire:model='searchLocality'>
                    <option value="" selected>Select Locality</option>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->locality->id); ?>"><?php echo e($item->locality->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-2 col-12 col-md-8 col-lg-8">
                <input type="text" wire:model="searchTerm" class="form-control" placeholder="Search Here" autofocus>
            </div>
        </div>
        <div class="mt-5 row">
            <?php if($doctors && $doctors->count() > 0): ?>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-4 text-center col-12 col-md-4 col-lg-4">
                        <div class="card w-100">
                            <div class="card-body image d-flex flex-column justify-content-center align-items-center">
                                <button class="btn btn-secondary">
                                    <?php if(!empty($doctor->photo)): ?>
                                        <img src="<?php echo e(asset('images/doctors/' . $doctor->photo)); ?>" height="100"
                                            width="100" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/doctors/no-doctor-image-300x300.png')); ?>"
                                            height="100" width="100" />
                                    <?php endif; ?>
                                </button>
                                <span class="mt-3 name">Dr. <?php echo e($doctor->name); ?></span>
                                <span class="idd"><?php echo e($doctor->qualification); ?></span>
                                <div class="flex-row gap-2 d-flex justify-content-center align-items-center">
                                    <span class="idd1"><?php echo e($doctor->department->title); ?></span>|<br>
                                    <span class="idd1"><?php echo e($doctor->locality->name); ?></span>
                                </div>
                                <div class="mt-2 d-flex">
                                    <a href="tel:+91-812592-0072">
                                        <button class="btn1 btn-dark">Book Appointment</button>
                                    </a>
                                </div>
                                <div class="mt-3 text">
                                    <span><?php echo e($doctor->about); ?></span>
                                </div>
                                <div class="flex-row gap-3 mt-3 icons d-flex justify-content-center align-items-center">
                                    <span>
                                        <a href="<?php echo e($doctor->t_link); ?>" target="_blank">
                                            <i class="bi bi-twitter"></i>
                                        </a>
                                    </span>
                                    <span>
                                        <a href="<?php echo e($doctor->f_link); ?>" target="_blank">
                                            <i class="bi bi-facebook"></i>
                                        </a>
                                    </span>
                                    <span>
                                        <a href="<?php echo e($doctor->i_link); ?>" target="_blank">
                                            <i class="bi bi-instagram"></i>
                                        </a>
                                    </span>
                                    <span>
                                        <a href="<?php echo e($doctor->l_link); ?>" target="_blank">
                                            <i class="bi bi-linkedin"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p class="text-center text-dark">No Doctors found</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /srv/http/aws_umdaa/resources/views/livewire/live-search.blade.php ENDPATH**/ ?>