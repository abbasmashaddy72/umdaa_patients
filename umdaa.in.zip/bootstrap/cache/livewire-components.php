<?php return array (
  'city-locality-dropdown' => 'App\\Http\\Livewire\\CityLocalityDropdown',
  'delete-doctor' => 'App\\Http\\Livewire\\DeleteDoctor',
  'delete-review' => 'App\\Http\\Livewire\\DeleteReview',
  'delete-service' => 'App\\Http\\Livewire\\DeleteService',
  'doctor-table' => 'App\\Http\\Livewire\\DoctorTable',
  'live-search' => 'App\\Http\\Livewire\\LiveSearch',
  'review-table' => 'App\\Http\\Livewire\\ReviewTable',
  'service-table' => 'App\\Http\\Livewire\\ServiceTable',
);